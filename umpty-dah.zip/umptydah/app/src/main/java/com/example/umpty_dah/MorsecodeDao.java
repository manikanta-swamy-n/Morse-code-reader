package com.example.umpty_dah;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface MorsecodeDao {

    @Query("SELECT * FROM morsecodeDB")
    List<MorsecodeDB> getAllmorsecodeDB();

@Insert
    void insertAll(MorsecodeDB[] morsecodeDBS);
}
