package com.example.umpty_dah;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "morsecodeDB")
public class MorsecodeDB {
    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo (name = "alphabet")
    private final String alphabet;

    @ColumnInfo (name = "morse_code")
    private final String morse_code;

    public MorsecodeDB(int id, String alphabet, String morse_code) {
        this.id = id;
        this.alphabet = alphabet;
        this.morse_code = morse_code;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAlphabet() {
        return alphabet;
    }

    public String getMorse_code() {
        return morse_code;
    }

}

