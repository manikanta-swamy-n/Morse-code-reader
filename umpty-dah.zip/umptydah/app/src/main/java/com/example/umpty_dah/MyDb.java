package com.example.umpty_dah;


import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;


@Database(entities = {MorsecodeDB.class}, exportSchema = false ,version = 1)
public abstract class MyDb extends RoomDatabase {

public static final Object LOCK = new Object();
    private static final String DB_NAME = "morsecodeDB.db";
    private static MyDb sinstance;
public static MyDb getInstance(final Context context){
    if(sinstance == null){
        synchronized (LOCK) {
            sinstance = Room.databaseBuilder(context.getApplicationContext(), MyDb.class, MyDb.DB_NAME)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .addCallback(new Callback() {
                        @Override
                        public void onCreate(@NonNull SupportSQLiteDatabase db) {
                            super.onCreate(db);
                            AppExecutors.getInstance().getDiskIO().execute(() -> getInstance(context).morsecodeDao().insertAll(populateDB.populatedb()));
                        }
                    }).build();
        }
    }
    return sinstance;

}
    public abstract MorsecodeDao morsecodeDao();
}
