package com.example.umpty_dah;

public class populateDB {
    public static MorsecodeDB[] populatedb() {
        return new MorsecodeDB[]{
                new MorsecodeDB(1, "A", ". ---"),
                new MorsecodeDB(2, "B", "--- . . ."),
                new MorsecodeDB(3, "C", "--- . --- ."),
                new MorsecodeDB(4, "D", "--- . ."),
                new MorsecodeDB(5, "E", "."),
                new MorsecodeDB(6, "F", ". . --- ."),
                new MorsecodeDB(7, "G", "--- --- ."),
                new MorsecodeDB(8, "H", ". . . ."),
                new MorsecodeDB(9, "I", ". ."),
                new MorsecodeDB(10, "J", ". --- --- ---"),
                new MorsecodeDB(11, "K", "--- . ---"),
                new MorsecodeDB(12, "L", ". --- . ."),
                new MorsecodeDB(13, "M", "--- ---"),
                new MorsecodeDB(14, "N", "--- ."),
                new MorsecodeDB(15, "O", "--- --- ---"),
                new MorsecodeDB(16, "P", ". --- --- ."),
                new MorsecodeDB(17, "Q", "--- --- . ---"),
                new MorsecodeDB(18, "R", ". --- ."),
                new MorsecodeDB(19, "S", ". . ."),
                new MorsecodeDB(20, "T", "---"),
                new MorsecodeDB(21, "U", ". . ---"),
                new MorsecodeDB(22, "V", ". . . ---"),
                new MorsecodeDB(23, "W", ". --- ---"),
                new MorsecodeDB(24, "X", "--- . . ---"),
                new MorsecodeDB(25, "Y", "--- . --- ---"),
                new MorsecodeDB(26, "Z", "--- --- . ."),
                new MorsecodeDB(27, "0", "--- --- --- --- ---"),
                new MorsecodeDB(28, "1", ". --- --- --- ---"),
                new MorsecodeDB(29, "2", ". . --- --- ---"),
                new MorsecodeDB(30, "3", ". . . --- ---"),
                new MorsecodeDB(31, "4", ". . . . ---"),
                new MorsecodeDB(32, "5", ". . . . ."),
                new MorsecodeDB(33, "6", "--- . . . ."),
                new MorsecodeDB(34, "7", "--- --- . . ."),
                new MorsecodeDB(35, "8", "--- --- --- . ."),
                new MorsecodeDB(36, "9", "--- --- --- --- .")};
    }
}
