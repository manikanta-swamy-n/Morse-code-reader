package com.example.umpty_dah;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;


public class hFragment extends Fragment {



    public hFragment() {
        // Required empty public constructor
    }
    AppCompatButton a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z;
    //Toolbar toolbar;
    TextView textView;
    View view;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_h, container, false);
        MyDb dbhelper = MyDb.getInstance(getActivity());
        ArrayList<MorsecodeDB> receive = (ArrayList<MorsecodeDB>) dbhelper.morsecodeDao().getAllmorsecodeDB();
         textView = view.findViewById(R.id.textView);

        init();

        a.setOnClickListener(view -> {
            a.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(a.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });

        b.setOnClickListener(view -> {
            for (int i = 0; i < receive.size(); i++) {
                if(b.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
            b.setBackgroundColor(-5);
        });
        c.setOnClickListener(view -> {
            c.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(c.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        d.setOnClickListener(view -> {
            d.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(d.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        e.setOnClickListener(view -> {
            e.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(e.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        f.setOnClickListener(view -> {
            f.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(f.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        g.setOnClickListener(view -> {
            g.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(g.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        h.setOnClickListener(view -> {
            h.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(h.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        i.setOnClickListener(view -> {
            i.setBackgroundColor(-5);
            for (int j = 0; j < receive.size(); j++) {
                if(i.getText().toString().toUpperCase().equals(receive.get(j).getAlphabet())){
                    textView.setText(receive.get(j).getMorse_code());
                }
            }
        });
        j.setOnClickListener(view -> {
            j.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(j.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        k.setOnClickListener(view -> {
            k.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(k.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        l.setOnClickListener(view -> {
            l.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(l.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        m.setOnClickListener(view -> {
            m.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(m.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        n.setOnClickListener(view -> {
            n.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(n.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        o.setOnClickListener(view -> {
            o.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(o.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        p.setOnClickListener(view -> {
            p.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(p.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        q.setOnClickListener(view -> {
            q.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(q.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        r.setOnClickListener(view -> {
            r.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(r.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        s.setOnClickListener(view -> {
            s.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(s.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        t.setOnClickListener(view -> {
            t.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(t.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        u.setOnClickListener(view -> {
            u.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(u.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        v.setOnClickListener(view -> {
            v.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(v.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        w.setOnClickListener(view -> {
            w.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(w.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }

        });
        x.setOnClickListener(view -> {
            x.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(x.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        y.setOnClickListener(view -> {
            y.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(y.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });
        z.setOnClickListener(view -> {
            z.setBackgroundColor(-5);
            for (int i = 0; i < receive.size(); i++) {
                if(z.getText().toString().toUpperCase().equals(receive.get(i).getAlphabet())){
                    textView.setText(receive.get(i).getMorse_code());
                }
            }
        });

        return view;
    }
    public void init(){
        a = view.findViewById(R.id.a);
        b = view.findViewById(R.id.b);
        c = view.findViewById(R.id.c);
        d = view.findViewById(R.id.d);
        e = view.findViewById(R.id.e);
        f = view.findViewById(R.id.f);
        g = view.findViewById(R.id.g);
        h = view.findViewById(R.id.h);
        i = view.findViewById(R.id.i);
        j = view.findViewById(R.id.j);
        k = view.findViewById(R.id.k);
        l = view.findViewById(R.id.l);
        m = view.findViewById(R.id.m);
        n = view.findViewById(R.id.n);
        o = view.findViewById(R.id.o);
        p = view.findViewById(R.id.p);
        q = view.findViewById(R.id.q);
        r = view.findViewById(R.id.r);
        s = view.findViewById(R.id.s);
        t = view.findViewById(R.id.t);
        u = view.findViewById(R.id.u);
        v = view.findViewById(R.id.v);
        w = view.findViewById(R.id.w);
        x = view.findViewById(R.id.x);
        y = view.findViewById(R.id.y);
        z = view.findViewById(R.id.z);
    }
}