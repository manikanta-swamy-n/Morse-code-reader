package com.example.umpty_dah;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import mehdi.sakout.aboutpage.AboutPage;
import mehdi.sakout.aboutpage.Element;



public class iFragment extends Fragment {


    public iFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment

        new Element();
        View aboutPage = new AboutPage(getActivity())
                .isRTL(false)
                .setDescription("Umpty_dah\n"+"this is my cs50 project\n" +
                        "International Morse Code\n" +
                        "was standardized at the International Telegraphy Congress in 1865 in Paris and was later made the standard by the" +
                        "International Telecommunication Union (ITU).")
                .setImage(R.drawable.logo)
                .addItem(new Element().setTitle("Version 1.0"))
                .addWebsite("https://en.wikipedia.org/w/index.php?title=Morse_code&oldid=1145114509","more about morsecode")
                .addGroup("Connect with us")
                .addEmail("mr.pheus4@gmail.com")
                .addYoutube("UCia6Fqzt6n16tTX1PAU4Gxw")
                .create();

        setContentView();

        return aboutPage;
    }


    public void setContentView() {
    }

}