package com.example.umpty_dah;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.Arrays;


public class aFragment extends Fragment {



    public aFragment() {


        // Required empty public constructor
    }

EditText editText,textView;
    AppCompatButton button;


    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_a, container, false);

        MyDb dbhelper = MyDb.getInstance(getActivity());

        ArrayList<MorsecodeDB> receive = (ArrayList<MorsecodeDB>) dbhelper.morsecodeDao().getAllmorsecodeDB();

        textView = view.findViewById(R.id.morseview);

        editText = view.findViewById(R.id.edittext);

        button = view.findViewById(R.id.convertbtn);

        button.setOnClickListener(view1 -> {
            String morse;

            String words = editText.getText().toString();

            String [] sepwords = words.toUpperCase().split("");

            ArrayList<String> text = new ArrayList<>(Arrays.asList(sepwords));

            StringBuilder result = new StringBuilder();

            for (int i = 0; i < text.size(); i++) {
                if (text.get(i).equals(" ")) {
                    result.append("       ");
                }
                for (int j = 0; j < receive.size(); j++) {
                    if (text.get(i).equals(receive.get(j).getAlphabet())){
                            morse = receive.get(j).getMorse_code();
                            result.append(morse).append("   ");
                    }
                }
            }
            textView.setText(result);


        });

        return view;
    }


}